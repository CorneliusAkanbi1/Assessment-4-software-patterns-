package com.example.softwarepatterns;

public class purchases {
}
