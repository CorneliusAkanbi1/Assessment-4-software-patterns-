package com.example.softwarepatterns;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class signup2 extends AppCompatActivity {

    EditText signupName2, signupEmail2, signupUsername2, signupPassword2;
    TextView loginRedirectText2;
    Button signupButton2;
    FirebaseDatabase database2;

    DatabaseReference reference2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup2);

        signupName2 = findViewById(R.id.signup_name2);
        signupEmail2 = findViewById(R.id.signup_email2);
        signupUsername2 = findViewById(R.id.signup_username2);
        signupPassword2 = findViewById(R.id.signup_password2);
        loginRedirectText2 = findViewById(R.id.loginRedirectText2);
        signupButton2 = findViewById(R.id.signup_button2);

        loginRedirectText2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(signup2.this, login2.class);
                startActivity(intent);
            }
        });

        signupButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                database2 = FirebaseDatabase.getInstance();
                reference2 = database2.getReference("Admins");

                String name2 = signupName2.getText().toString();
                String email2 = signupEmail2.getText().toString();
                String username2 = signupUsername2.getText().toString();
                String password2 = signupPassword2.getText().toString();

                // Create an Admin object with name, email, username, and password
                Admin admin = new Admin(name2, email2, username2, password2);

                // Pushing user object to the database with username as key
                reference2.child(username2).setValue(admin)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(signup2.this, "You have signed up successfully!", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(signup2.this, login.class);
                                startActivity(intent);
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.e("SignupActivity2", "Error adding user to database: " + e.getMessage());
                                Toast.makeText(signup2.this, "Error signing up. Please try again.", Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });
    }
}
