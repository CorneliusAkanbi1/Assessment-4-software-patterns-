package com.example.softwarepatterns;

public class Admin {
    String name2;
    String email2;

    public String getName2() {
        return name2;
    }

    public void setName2(String name2) {
        this.name2 = name2;
    }

    public String getEmail2() {
        return email2;
    }

    public void setEmail2(String email2) {
        this.email2 = email2;
    }

    public String getUsername2() {
        return username2;
    }

    public void setUsername2(String username2) {
        this.username2 = username2;
    }

    public String getPassword2() {
        return password2;
    }

    public void setPassword2(String password2) {
        this.password2 = password2;
    }

    String username2;
    String password2;

    public Admin(String name2, String email2, String username2, String password2) {
        this.name2 = name2;
        this.email2 = email2;
        this.username2 = username2;
        this.password2 = password2;
    }

    public Admin() {
    }
}
