package com.example.ca2_2023;

public class User {
    private String userId;
    private String email;
    private String fullname;
    // Empty constructor (required for Firebase)
    public User() {
    }

    // Parameterized constructor
    public User(String userId, String email, String fullname) {
        this.userId = userId;
        this.email = email;
        this.fullname = fullname;
    }

    // Getter and Setter methods
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }


    // toString method to represent the User object as a string
    @Override
    public String toString() {
        // Customize the string representation of the Task
        return "Email: " + email + ", Fullname: " + fullname;
    }
}
