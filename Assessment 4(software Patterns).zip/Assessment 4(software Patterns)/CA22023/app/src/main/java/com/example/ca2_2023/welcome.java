package com.example.ca2_2023;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class welcome extends AppCompatActivity {

    private static final String TAG = "WelcomeActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        // Retrieve phone number from intent
        String phone = getIntent().getStringExtra("phone");

        // Check if the phone number is not null
        if (phone != null) {
            DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("users").child(phone);
            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        Log.d(TAG, "User data exists");

                        // Check if 'fullname' field exists in the snapshot
                        if (snapshot.hasChild("fullname")) {
                            Log.d(TAG, "Fullname field exists");

                            String userName = snapshot.child("fullname").getValue(String.class);
                            Log.d(TAG, "User Name: " + userName);

                            // Update the TextViews with the user's information
                            TextView welcomeMessage = findViewById(R.id.welcomeMessage);
                            welcomeMessage.setText("Welcome, " + userName);

                            TextView userNameTextView = findViewById(R.id.userName);
                            userNameTextView.setText("User Name: " + userName);

                            TextView userPhoneNumberTextView = findViewById(R.id.userPhoneNumber);
                            userPhoneNumberTextView.setText("Phone Number: " + phone);
                        } else {
                            Log.e(TAG, "Fullname field is missing");
                            // Handle the case where 'fullname' field is missing in the database
                            handleMissingFields();
                        }
                    } else {
                        Log.e(TAG, "User data does not exist");
                        // Handle the case where the user data does not exist in the database
                        handleUserDataNotExists();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    // Handle database error
                    handleDatabaseError(error);
                }
            });
        } else {
            Log.e(TAG, "Phone is null");
            // Handle the case where phone is null
            handleNullPhone();
        }

        // Set up click listeners for buttons
        Button btnWeather = findViewById(R.id.btnShop);
        Button btnEditTask = findViewById(R.id.btnCheckout);
        Button btnMaps = findViewById(R.id.btnPurchases);

        btnWeather.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handle the click for Weather button
                startActivity(new Intent(welcome.this, Shop.class));
            }
        });

        btnEditTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handle the click for Edit Task button
                // Add your logic here
                startActivity(new Intent(welcome.this, Purchases.class));
            }
        });


        btnMaps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handle the click for Maps button
                // Add your logic here
                startActivity(new Intent(welcome.this, Checkout.class));
            }
        });

    }

    // ... (Remaining code)

    // Add your custom logic for handling missing fields
    private void handleMissingFields() {
        // For example, display an error message or guide the user to complete their profile
    }

    // Add your custom logic for handling the case where user data does not exist
    private void handleUserDataNotExists() {
        // For example, display an error message or guide the user to complete their profile
    }

    // Add your custom logic for handling database errors
    private void handleDatabaseError(DatabaseError error) {
        // For example, display an error message or log the error for further investigation
    }

    // Add your custom logic for handling the case where phone is null
    private void handleNullPhone() {
        // For example, display an error message or take appropriate actions based on your app's logic
    }
}
