package com.example.ca2_2023;

import models.NewsHeadlines;

public interface SelectListener {
    void OnNewsClicked(NewsHeadlines headlines);
}
