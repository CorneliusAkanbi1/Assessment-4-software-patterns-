package com.example.softwarepatterns;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CheckoutAdapter extends RecyclerView.Adapter<CheckoutAdapter.ViewHolder> {

    private List<BasketItem> basketItemList;
    private Context context;
    private int selectedPosition = RecyclerView.NO_POSITION;

    public CheckoutAdapter(List<BasketItem> basketItemList, Context context) {
        this.basketItemList = basketItemList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.basket_item_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BasketItem basketItem = basketItemList.get(position);
        holder.bind(basketItem);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notifyItemChanged(selectedPosition);
                selectedPosition = holder.getAdapterPosition();
                notifyItemChanged(selectedPosition);
            }
        });

        // Highlight the selected item
        holder.itemView.setSelected(selectedPosition == position);
    }

    @Override
    public int getItemCount() {
        return basketItemList.size();
    }

    public int getSelectedPosition() {
        return selectedPosition;
    }

    public void removeItem(int position) {
        if (position >= 0 && position < basketItemList.size()) { // Check if position is valid
            basketItemList.remove(position);
            notifyItemRemoved(position);
        } else {
            // Log the error
            Log.e("CheckoutAdapter", "Invalid position: " + position);
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView titleTextView;
        private TextView manufacturerTextView;
        private TextView priceTextView;
        private TextView quantityTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.titleTextView);
            manufacturerTextView = itemView.findViewById(R.id.manufacturerTextView);
            priceTextView = itemView.findViewById(R.id.priceTextView);
            quantityTextView = itemView.findViewById(R.id.quantityTextView);
        }

        public void bind(BasketItem basketItem) {
            titleTextView.setText("Title: " + basketItem.getTitle());
            manufacturerTextView.setText("Manufacturer: " + basketItem.getManufacturer());
            priceTextView.setText("Price: $" + basketItem.getPrice());
            quantityTextView.setText("Quantity: " + basketItem.getQuantity());
        }
    }
}
