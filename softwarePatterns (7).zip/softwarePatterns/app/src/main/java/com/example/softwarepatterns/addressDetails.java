package com.example.softwarepatterns;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class addressDetails extends AppCompatActivity {

    private EditText addressLine1EditText;
    private EditText cityEditText;
    private EditText eirCodeEditText;
    private EditText countryEditText;
    private Button completePurchaseButton;

    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_address_details);

        username = getIntent().getStringExtra("username");

        if (username == null || username.isEmpty()) {
            // Handle the case where username is not provided
            Toast.makeText(this, "Username not found", Toast.LENGTH_SHORT).show();
            finish(); // Finish the activity if username is not provided
            return;
        }

        addressLine1EditText = findViewById(R.id.addressLine1);
        cityEditText = findViewById(R.id.city);
        eirCodeEditText = findViewById(R.id.eirCode);
        countryEditText = findViewById(R.id.country);
        completePurchaseButton = findViewById(R.id.completePurchase_button);

        completePurchaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveAddressDetailsAndNavigate();
            }
        });
    }

    private void saveAddressDetailsAndNavigate() {
        String addressLine1 = addressLine1EditText.getText().toString().trim();
        String city = cityEditText.getText().toString().trim();
        String eirCode = eirCodeEditText.getText().toString().trim();
        String country = countryEditText.getText().toString().trim();

        // Validate address details
        if (addressLine1.isEmpty() || city.isEmpty() || eirCode.isEmpty() || country.isEmpty()) {
            Toast.makeText(this, "Please fill in all address details", Toast.LENGTH_SHORT).show();
            return;
        }

        // Save address details under the specific username node in Firebase
        DatabaseReference addressRef = FirebaseDatabase.getInstance().getReference("Users").child(username).child("address");
        Address address = new Address(addressLine1, city, eirCode, country);
        addressRef.setValue(address);

        Toast.makeText(this, "Address details saved successfully", Toast.LENGTH_SHORT).show();

        // Move items from "baskets" node to "purchases" node
        DatabaseReference basketRef = FirebaseDatabase.getInstance().getReference("Users").child(username).child("baskets");
        DatabaseReference purchaseRef = FirebaseDatabase.getInstance().getReference("Users").child(username).child("purchases");

        basketRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    BasketItem basketItem = snapshot.getValue(BasketItem.class);
                    String purchaseItemId = purchaseRef.push().getKey();
                    purchaseRef.child(purchaseItemId).setValue(basketItem);

                    // Update the stock quantities
                    updateStockQuantities(basketItem);
                }

                // Delete the "baskets" node
                basketRef.removeValue();

                // Navigate to the PurchaseActivity
                Intent intent = new Intent(addressDetails.this, PurchaseActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);

                // Finish the current activity
                finish();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle database error
            }
        });
    }

    private void updateStockQuantities(BasketItem basketItem) {
        DatabaseReference stockRef = FirebaseDatabase.getInstance().getReference("Stock");

        // Query the stock for the item to be updated
        stockRef.orderByChild("title").equalTo(basketItem.getTitle()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Stock stock = snapshot.getValue(Stock.class);

                    // Calculate the new quantity after purchase
                    int updatedQuantity = stock.getQuantity() - basketItem.getQuantity();

                    // Update the stock quantity
                    snapshot.getRef().child("quantity").setValue(updatedQuantity);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle database error
            }
        });
    }



}
