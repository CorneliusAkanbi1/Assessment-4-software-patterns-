package com.example.softwarepatterns;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class PurchaseAdapter extends RecyclerView.Adapter<PurchaseAdapter.PurchaseViewHolder> {

    private List<purchases> purchaseList;

    public PurchaseAdapter() {
        this.purchaseList = new ArrayList<>();
    }

    @NonNull
    @Override
    public PurchaseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.purchase_item_layout, parent, false);
        return new PurchaseViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PurchaseViewHolder holder, int position) {
        purchases purchase = purchaseList.get(position);
        // Bind purchase data to the view holder
        holder.bind(purchase);
    }

    @Override
    public int getItemCount() {
        return purchaseList.size();
    }

    public void addItem(purchases purchase) {
        purchaseList.add(purchase);
        notifyDataSetChanged();
    }

    public void clearItems() {
        purchaseList.clear();
        notifyDataSetChanged();
    }

    static class PurchaseViewHolder extends RecyclerView.ViewHolder {
        private TextView itemNameTextView;
        private TextView itemPriceTextView;
        private TextView itemQuantityTextView;
        private TextView itemManufacturerTextView;

        public PurchaseViewHolder(@NonNull View itemView) {
            super(itemView);
            itemNameTextView = itemView.findViewById(R.id.itemNameTextView);
            itemPriceTextView = itemView.findViewById(R.id.itemPriceTextView);
            itemQuantityTextView = itemView.findViewById(R.id.itemQuantityTextView);
            itemManufacturerTextView = itemView.findViewById(R.id.itemManufacturerTextView);
        }

        public void bind(purchases purchase) {
            itemNameTextView.setText(purchase.getTitle());
            String priceText = "Price: $" + purchase.getPrice();
            itemPriceTextView.setText(priceText);
            String quantityText = "Quantity: " + purchase.getQuantity();
            itemQuantityTextView.setText(quantityText);
            itemManufacturerTextView.setText("Manufacturer: " + purchase.getManufacturer());
        }
    }
}
