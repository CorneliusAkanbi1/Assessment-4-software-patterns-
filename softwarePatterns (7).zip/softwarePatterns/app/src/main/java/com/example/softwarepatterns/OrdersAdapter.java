package com.example.softwarepatterns;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class OrdersAdapter extends RecyclerView.Adapter<OrdersAdapter.PurchaseViewHolder> {

    private List<purchases> purchasesList;

    public OrdersAdapter(List<purchases> purchasesList) {
        this.purchasesList = purchasesList;
    }

    @NonNull
    @Override
    public PurchaseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_item_layout, parent, false);
        return new PurchaseViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PurchaseViewHolder holder, int position) {
        purchases purchase = purchasesList.get(position);
        holder.bind(purchase);
    }

    @Override
    public int getItemCount() {
        return purchasesList.size();
    }

    static class PurchaseViewHolder extends RecyclerView.ViewHolder {
        private TextView titleTextView;
        private TextView manufacturerTextView;
        private TextView priceTextView;
        private TextView quantityTextView;

        public PurchaseViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.titleTextView);
            manufacturerTextView = itemView.findViewById(R.id.manufacturerTextView);
            priceTextView = itemView.findViewById(R.id.priceTextView);
            quantityTextView = itemView.findViewById(R.id.quantityTextView);
        }

        public void bind(purchases purchase) {
            titleTextView.setText("Title: " + purchase.getTitle());
            manufacturerTextView.setText("Manufacturer: " + purchase.getManufacturer());
            priceTextView.setText("Price: $" + purchase.getPrice());
            quantityTextView.setText("Quantity: " + purchase.getQuantity());
        }
    }
}
