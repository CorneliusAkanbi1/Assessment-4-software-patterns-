package com.example.softwarepatterns;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class StockAdapter extends RecyclerView.Adapter<StockAdapter.StockViewHolder> {

    private List<Stock> stockList;
    private List<Stock> fullStockList; // Store the full list to restore when search query is empty
    private int selectedPosition = RecyclerView.NO_POSITION; // Initially no item selected
    private OnItemClickListener listener; // Listener for item click events

    public StockAdapter(List<Stock> stockList) {
        this.stockList = stockList;
        this.fullStockList = new ArrayList<>(stockList);
    }

    @NonNull
    @Override
    public StockViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.stock_item, parent, false);
        return new StockViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StockViewHolder holder, int position) {
        Stock stock = stockList.get(position);
        holder.textViewTitle.setText(stock.getTitle());
        holder.textViewManufacturer.setText(stock.getManufacturer());
        holder.textViewPrice.setText("Price: $" + stock.getPrice());
        holder.textViewQuantity.setText("Quantity: " + stock.getQuantity());

        // Highlight selected item
        holder.itemView.setSelected(selectedPosition == position);

        // Set click listener for the item
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int previousSelectedPosition = selectedPosition;
                selectedPosition = position;
                notifyItemChanged(previousSelectedPosition);
                notifyItemChanged(selectedPosition);

                if (listener != null) {
                    listener.onItemClick(position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return stockList.size();
    }

    public void filterList(String query) {
        filterList(query, "title"); // Default sorting by title
    }

    public void filterList(String query, String sortingAttribute) {
        stockList.clear();
        if (query.isEmpty()) {
            stockList.addAll(fullStockList); // Restore full list if query is empty
        } else {
            query = query.toLowerCase().trim();
            for (Stock stock : fullStockList) {
                if (stock.getTitle().toLowerCase().contains(query)
                        || stock.getManufacturer().toLowerCase().contains(query)
                        || String.valueOf(stock.getPrice()).contains(query)) {
                    stockList.add(stock);
                }
            }
        }
        sortList(sortingAttribute);
        notifyDataSetChanged();
    }

    private void sortList(String sortingAttribute) {
        // Sort the list based on the selected attribute
        switch (sortingAttribute) {
            case "title":
                Collections.sort(stockList, new Comparator<Stock>() {
                    @Override
                    public int compare(Stock s1, Stock s2) {
                        return s1.getTitle().compareToIgnoreCase(s2.getTitle());
                    }
                });
                break;
            case "manufacturer":
                Collections.sort(stockList, new Comparator<Stock>() {
                    @Override
                    public int compare(Stock s1, Stock s2) {
                        return s1.getManufacturer().compareToIgnoreCase(s2.getManufacturer());
                    }
                });
                break;
            case "price":
                Collections.sort(stockList, new Comparator<Stock>() {
                    @Override
                    public int compare(Stock s1, Stock s2) {
                        return Integer.compare(s1.getPrice(), s2.getPrice());
                    }
                });
                break;
            // Add more cases for other sorting attributes if needed
        }
    }

    public int getSelectedPosition() {
        return selectedPosition;
    }

    public void setSelectedPosition(int position) {
        selectedPosition = position;
        notifyDataSetChanged();
    }

    // Setter for the item click listener
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    // Interface for item click events
    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public static class StockViewHolder extends RecyclerView.ViewHolder {
        TextView textViewTitle;
        TextView textViewManufacturer;
        TextView textViewPrice;
        TextView textViewQuantity;

        public StockViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewTitle = itemView.findViewById(R.id.titleTextView);
            textViewManufacturer = itemView.findViewById(R.id.manufacturerTextView);
            textViewPrice = itemView.findViewById(R.id.priceTextView);
            textViewQuantity = itemView.findViewById(R.id.quantityTextView);
        }
    }
}
