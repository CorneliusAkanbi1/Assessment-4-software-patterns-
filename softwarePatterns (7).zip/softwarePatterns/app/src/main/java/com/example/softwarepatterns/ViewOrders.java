package com.example.softwarepatterns;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ViewOrders extends AppCompatActivity {

    private RecyclerView recyclerViewOrders;
    private OrdersAdapter ordersAdapter;
    private List<purchases> purchasesList;
    private TextView orderRedirectText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_orders);

        recyclerViewOrders = findViewById(R.id.recyclerViewOrders);
        recyclerViewOrders.setHasFixedSize(true);
        recyclerViewOrders.setLayoutManager(new LinearLayoutManager(this));

        purchasesList = new ArrayList<>();
        ordersAdapter = new OrdersAdapter(purchasesList);
        recyclerViewOrders.setAdapter(ordersAdapter);

        // Retrieve users from Firebase database
        DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("Users");
        usersRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                    // Retrieve purchases for each user
                    DataSnapshot purchasesSnapshot = userSnapshot.child("purchases");
                    for (DataSnapshot purchaseSnapshot : purchasesSnapshot.getChildren()) {
                        purchases purchase = purchaseSnapshot.getValue(purchases.class);
                        purchasesList.add(purchase);
                    }
                }
                ordersAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("ViewOrdersActivity", "Error fetching orders: " + databaseError.getMessage());
                Toast.makeText(ViewOrders.this, "Error fetching orders", Toast.LENGTH_SHORT).show();
            }
        });

        // Initialize orderRedirectText and set OnClickListener
        orderRedirectText = findViewById(R.id.orderRedirectText);
        orderRedirectText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ViewOrders.this, MainActivity2.class);
                startActivity(intent);
            }
        });
    }
}
