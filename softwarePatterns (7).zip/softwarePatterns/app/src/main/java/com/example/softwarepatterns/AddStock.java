package com.example.softwarepatterns;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddStock extends AppCompatActivity {

    EditText title, manufacturer, price, quantity;
    Button add;
    TextView stockRedirectText;
    FirebaseDatabase database;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_stock);

        title = findViewById(R.id.title);
        manufacturer = findViewById(R.id.manufacturer);
        price = findViewById(R.id.price);
        quantity = findViewById(R.id.quantity);
        add = findViewById(R.id.Add_button);
        stockRedirectText = findViewById(R.id.stockRedirectText); // assuming you have a button with id back_button in your layout

        stockRedirectText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AddStock.this, UpdateStock.class);
                startActivity(intent);
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                database = FirebaseDatabase.getInstance();
                reference = database.getReference("Stock");

                String stockTitle = title.getText().toString();
                String stockManufacturer = manufacturer.getText().toString();
                int stockPrice = Integer.parseInt(price.getText().toString());
                int stockQuantity = Integer.parseInt(quantity.getText().toString());

                Stock stock = new Stock(stockTitle, stockManufacturer, stockPrice, stockQuantity);

                reference.child(stockTitle).setValue(stock)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(AddStock.this, "You have added stock successfully!", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.e("AddStock", "Error adding Stock to database: " + e.getMessage());
                                Toast.makeText(AddStock.this, "Error adding stock. Please try again.", Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });


    }
}
