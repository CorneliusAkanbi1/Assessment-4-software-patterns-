package com.example.softwarepatterns;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.softwarepatterns.R;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        String username2 = getIntent().getStringExtra("username"); // Retrieve username from inten

        Button btnAddStock = findViewById(R.id.btnAddStock);
        btnAddStock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to AddStock activity
                Intent intent = new Intent(MainActivity2.this, UpdateStock.class);
                startActivity(intent);
            }
        });

        Button btnViewUsers = findViewById(R.id.btnUsers);
        btnViewUsers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to viewUsers activity
                Intent intent = new Intent(MainActivity2.this, ViewUsers.class);
                startActivity(intent);
            }
        });

        Button btnViewOrders = findViewById(R.id.btnOrders);
        btnViewOrders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to viewUsers activity
                Intent intent = new Intent(MainActivity2.this, ViewOrders.class);
                startActivity(intent);
            }
        });
    }
}
