package com.example.softwarepatterns;

public class Address {
    private String addressLine1;
    private String city;
    private String eirCode;
    private String country;

    public Address() {
    }

    // Constructor
    public Address(String addressLine1, String city, String eirCode, String country) {
        this.addressLine1 = addressLine1;
        this.city = city;
        this.eirCode = eirCode;
        this.country = country;
    }

    // Getters and Setters
    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getEirCode() {
        return eirCode;
    }

    public void setEirCode(String eirCode) {
        this.eirCode = eirCode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
}
