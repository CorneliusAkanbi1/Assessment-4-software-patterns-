package com.example.softwarepatterns;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class PurchaseActivity extends AppCompatActivity {

    private TextView userNameTextView, emailTextView, cardExpiryTextView, addressTextView, cityTextView, countryTextView, eirCodeTextView;
    private RecyclerView recyclerViewPurchase;
    private PurchaseAdapter purchaseAdapter;
    private TextView purchaseRedirectText;
    private TextView totalMessageTextView;
    private EditText discountEditText;

    private String username;

    private boolean discountApplied = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_purchase);

        userNameTextView = findViewById(R.id.userName);
        emailTextView = findViewById(R.id.email);
        cardExpiryTextView = findViewById(R.id.cardExipry);
        addressTextView = findViewById(R.id.addressPurchase);
        cityTextView = findViewById(R.id.cityPurchase);
        countryTextView = findViewById(R.id.countryPurchase);
        eirCodeTextView = findViewById(R.id.eirCodePurchase);
        recyclerViewPurchase = findViewById(R.id.recyclerViewPurchase);
        totalMessageTextView = findViewById(R.id.totalMessage);
        purchaseRedirectText = findViewById(R.id.purchaseRedirectText);
        discountEditText = findViewById(R.id.discount);

        username = getIntent().getStringExtra("username");

        purchaseRedirectText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PurchaseActivity.this, MainActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);
                finish();
            }
        });

        if (username != null) {
            DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("Users").child(username);
            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    User user = dataSnapshot.getValue(User.class);
                    if (user != null) {
                        userNameTextView.setText("Username: " + user.getUsername());
                        emailTextView.setText("Email: " + user.getEmail());
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    // Handle database error
                }
            });

            DatabaseReference cardRef = FirebaseDatabase.getInstance().getReference("Users").child(username).child("cardDetails");
            cardRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Card card = dataSnapshot.getValue(Card.class);
                    if (card != null) {
                        cardExpiryTextView.setText("Card Expiry Date: " + card.getExpireDate());
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    // Handle database error
                }
            });

            DatabaseReference addressRef = FirebaseDatabase.getInstance().getReference("Users").child(username).child("address");
            addressRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Address address = dataSnapshot.getValue(Address.class);
                    if (address != null) {
                        addressTextView.setText("Address: " + address.getAddressLine1());
                        cityTextView.setText("City: " + address.getCity());
                        countryTextView.setText("Country: " + address.getCountry());
                        eirCodeTextView.setText("Eir Code: " + address.getEirCode());
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    // Handle database error
                }
            });

            recyclerViewPurchase.setLayoutManager(new LinearLayoutManager(this));
            purchaseAdapter = new PurchaseAdapter(this); // Pass context to adapter constructor
            recyclerViewPurchase.setAdapter(purchaseAdapter);

            DatabaseReference purchaseRef = FirebaseDatabase.getInstance().getReference("Users").child(username).child("purchases");
            purchaseRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    purchaseAdapter.clearItems();
                    int total = 0;
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        purchases purchase = snapshot.getValue(purchases.class);
                        if (purchase != null) {
                            purchaseAdapter.addItem(purchase);
                            total += purchase.getPrice() * purchase.getQuantity();
                        }
                    }
                    if (discountApplied) {
                        total *= 0.9; // Apply 10% discount
                    }
                    totalMessageTextView.setText("Total: $" + total);
                    purchaseAdapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    // Handle database error
                }
            });

            findViewById(R.id.discount).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String discountCode = discountEditText.getText().toString().trim();
                    if ("discount10".equals(discountCode)) {
                        if (!discountApplied) {
                            discountApplied = true;
                            Toast.makeText(PurchaseActivity.this, "Discount has been added to your total", Toast.LENGTH_SHORT).show();
                            int total = Integer.parseInt(totalMessageTextView.getText().toString().replaceAll("[^\\d.]", ""));
                            total *= 0.9; // Apply 10% discount
                            totalMessageTextView.setText("Total: $" + total);
                        } else {
                            Toast.makeText(PurchaseActivity.this, "Discount has already been applied", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(PurchaseActivity.this, "Invalid discount code", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        } else {
            finish();
        }
    }
}
