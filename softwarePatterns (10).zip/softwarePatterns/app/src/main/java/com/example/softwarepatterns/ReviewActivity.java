package com.example.softwarepatterns;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.RatingBar;

import com.example.softwarepatterns.R;

public class ReviewActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_rating_review);

        // Find views
        RatingBar ratingBar = findViewById(R.id.ratingBar);
        EditText reviewEditText = findViewById(R.id.reviewEditText);

        // Create AlertDialog.Builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Review");

        // Inflate the custom layout for the dialog
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_rating_review, null);
        builder.setView(dialogView);

        // Set up the RatingBar and EditText from the custom layout
        RatingBar dialogRatingBar = dialogView.findViewById(R.id.ratingBar);
        EditText dialogReviewEditText = dialogView.findViewById(R.id.reviewEditText);

        // Set positive button
        builder.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                float rating = dialogRatingBar.getRating();
                String review = dialogReviewEditText.getText().toString();

                // Here, you can handle the submission of the review data
                // For example, you can send it to a database or display it in your app
            }
        });

        // Set negative button
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Cancel the dialog
                dialog.dismiss();
            }
        });

        // Create and show the AlertDialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
