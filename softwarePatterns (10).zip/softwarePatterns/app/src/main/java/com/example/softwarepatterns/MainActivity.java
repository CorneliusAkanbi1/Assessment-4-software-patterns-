package com.example.softwarepatterns;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

// Import statements...

// Import statements...

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private TextView mainActivityRedirecttext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainActivityRedirecttext = findViewById(R.id.mainActivityRedirectText);
        mainActivityRedirecttext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, login.class);
                startActivity(intent);
            }
        });
        String username = getIntent().getStringExtra("username"); // Retrieve username from intent

        // Update the TextViews with the user's information
        TextView welcomeMessage = findViewById(R.id.welcomeMessage);
        welcomeMessage.setText("Welcome, " + username);

        TextView userNameTextView = findViewById(R.id.userName);
        userNameTextView.setText("User Name: " + username);

        // Set up click listeners for buttons
        Button btnShop = findViewById(R.id.btnShop);
        btnShop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to AddStock activity
                Intent intent = new Intent(MainActivity.this, shop.class);
                intent.putExtra("username", username);
                startActivity(intent);
            }
        });

        Button btnCheckout = findViewById(R.id.btnCheckout);
        btnCheckout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to AddStock activity
                Intent intent = new Intent(MainActivity.this, checkout.class);
                intent.putExtra("username", username);
                startActivity(intent);
            }
        });

        Button btnPurchases = findViewById(R.id.btnPurchases);
        btnPurchases.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to PurchaseActivity
                Intent intent = new Intent(MainActivity.this, PurchaseActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);
            }
        });

        // Button click listeners...
    }
    private void handleNullUserData() {
        // For example, display an error message or guide the user to complete their profile
    }

    // Add your custom logic for handling the case where user data does not exist
    private void handleUserDataNotExists() {
        // For example, display an error message or guide the user to complete their profile
    }

    // Add your custom logic for handling database errors
    private void handleDatabaseError(DatabaseError error) {
        // For example, display an error message or log the error for further investigation
    }

    // Add your custom logic for handling the case where phone is null
    private void handleNullUsername() {
        // For example, display an error message or take appropriate actions based on your app's logic
    }
}
