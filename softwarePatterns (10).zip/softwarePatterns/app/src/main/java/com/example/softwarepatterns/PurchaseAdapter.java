package com.example.softwarepatterns;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class PurchaseAdapter extends RecyclerView.Adapter<PurchaseAdapter.PurchaseViewHolder> {

    private List<purchases> purchaseList;
    private Context context;

    public PurchaseAdapter(Context context) {
        this.context = context;
        this.purchaseList = new ArrayList<>();
    }

    @NonNull
    @Override
    public PurchaseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.purchase_item_layout, parent, false);
        return new PurchaseViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PurchaseViewHolder holder, int position) {
        purchases purchase = purchaseList.get(position);
        holder.bind(purchase);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showRatingReviewDialog();
            }
        });
    }

    @Override
    public int getItemCount() {
        return purchaseList.size();
    }

    public void addItem(purchases purchase) {
        purchaseList.add(purchase);
        notifyDataSetChanged();
    }

    public void clearItems() {
        purchaseList.clear();
        notifyDataSetChanged();
    }

    static class PurchaseViewHolder extends RecyclerView.ViewHolder {
        private TextView itemNameTextView;
        private TextView itemPriceTextView;
        private TextView itemQuantityTextView;
        private TextView itemManufacturerTextView;

        public PurchaseViewHolder(@NonNull View itemView) {
            super(itemView);
            itemNameTextView = itemView.findViewById(R.id.itemNameTextView);
            itemPriceTextView = itemView.findViewById(R.id.itemPriceTextView);
            itemQuantityTextView = itemView.findViewById(R.id.itemQuantityTextView);
            itemManufacturerTextView = itemView.findViewById(R.id.itemManufacturerTextView);
        }

        public void bind(purchases purchase) {
            itemNameTextView.setText(purchase.getTitle());
            String priceText = "Price: $" + purchase.getPrice();
            itemPriceTextView.setText(priceText);
            String quantityText = "Quantity: " + purchase.getQuantity();
            itemQuantityTextView.setText(quantityText);
            itemManufacturerTextView.setText("Manufacturer: " + purchase.getManufacturer());
        }
    }

    private void showRatingReviewDialog() {
        View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_rating_review, null);

        RatingBar ratingBar = dialogView.findViewById(R.id.ratingBar);
        EditText reviewEditText = dialogView.findViewById(R.id.reviewEditText);

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setView(dialogView)
                .setTitle("Rate and Review")
                .setPositiveButton("Submit", (dialogInterface, i) -> {
                    float rating = ratingBar.getRating();
                    String review = reviewEditText.getText().toString();
                    // Handle rating and review submission
                    // For example, send to Firebase
                })
                .setNegativeButton("Cancel", (dialogInterface, i) -> dialogInterface.dismiss())
                .create()
                .show();
    }
}
