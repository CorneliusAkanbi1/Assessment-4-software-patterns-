package com.example.softwarepatterns;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class login2 extends AppCompatActivity {

    EditText loginUsername2, loginPassword2;
    Button loginButton2;
    TextView loginRedirectButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);

        loginUsername2 = findViewById(R.id.login_username2);
        loginPassword2 = findViewById(R.id.login_password2);
        loginRedirectButton = findViewById(R.id.loginRedirectText);
        loginButton2 = findViewById(R.id.login_button2);

        loginButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!validateUsername2() || !validatePassword2()) {
                    // Validation failed
                } else {
                    checkAdmin();
                }
            }
        });

        loginRedirectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(login2.this, login.class);
                startActivity(intent);
            }
        });
    }

    public boolean validateUsername2(){
        String val = loginUsername2.getText().toString();
        if (val.isEmpty()){
            loginUsername2.setError("Username cannot be empty");
            return false;
        } else {
            loginUsername2.setError(null);
            return true;
        }
    }

    public boolean validatePassword2(){
        String val = loginPassword2.getText().toString();
        if (val.isEmpty()){
            loginPassword2.setError("Password cannot be empty");
            return false;
        } else {
            loginPassword2.setError(null);
            return true;
        }
    }

    public void checkAdmin() {
        String userUsername2 = loginUsername2.getText().toString().trim();
        String userPassword2 = loginPassword2.getText().toString().trim();

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Admins"); // Corrected reference
        Query checkAdminDatabase = reference.orderByChild("username2").equalTo(userUsername2);

        checkAdminDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Log.d("LoginActivity2", "Snapshot exists: " + snapshot.exists());
                Log.d("LoginActivity2", "Snapshot value: " + snapshot.getValue());

                if (snapshot.exists()) {
                    for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                        String passwordFromDB = userSnapshot.child("password2").getValue(String.class);
                        Log.d("LoginActivity2", "Password from DB: " + passwordFromDB);

                        if (passwordFromDB != null && passwordFromDB.equals(userPassword2)) {
                            // Login successful
                            Intent intent = new Intent(login2.this, MainActivity2.class);
                            startActivity(intent);
                            return; // Exit method after successful login
                        }
                    }
                    // If password doesn't match for any user
                    loginPassword2.setError("Invalid Credentials");
                    loginPassword2.requestFocus();
                } else {
                    // User does not exist
                    loginUsername2.setError("Admin does not exist");
                    loginUsername2.requestFocus();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("LoginActivity2", "Database error: " + error.getMessage());
            }
        });
    }


}
