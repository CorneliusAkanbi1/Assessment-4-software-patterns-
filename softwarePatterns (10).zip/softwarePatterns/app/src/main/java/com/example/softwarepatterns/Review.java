package com.example.softwarepatterns;

public class Review {
    private String content;
    private String reviewerUsername;

    public Review() {
        // Default constructor required for Firebase
    }

    public Review(String content, String reviewerUsername) {
        this.content = content;
        this.reviewerUsername = reviewerUsername;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getReviewerUsername() {
        return reviewerUsername;
    }

    public void setReviewerUsername(String reviewerUsername) {
        this.reviewerUsername = reviewerUsername;
    }
}
