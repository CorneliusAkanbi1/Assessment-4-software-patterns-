package com.example.softwarepatterns;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class UpdateStock extends AppCompatActivity {

    private RecyclerView recyclerView;
    private StockAdapter stockAdapter;
    private List<Stock> stockList;

    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_stock);

        recyclerView = findViewById(R.id.recyclerViewUpdate);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        stockList = new ArrayList<>();
        stockAdapter = new StockAdapter(stockList);
        recyclerView.setAdapter(stockAdapter);

        databaseReference = FirebaseDatabase.getInstance().getReference("Stock");

        // Read data from Firebase Database
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                stockList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Stock stock = snapshot.getValue(Stock.class);
                    stockList.add(stock);
                }
                stockAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle database error
            }
        });

        // Handle click on "back to home page" TextView
        TextView updateRedirectText = findViewById(R.id.updateRedirectText);
        updateRedirectText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UpdateStock.this, MainActivity2.class);
                startActivity(intent);
            }
        });

        // Handle click on "Add Stock" Button
        Button addStockButton = findViewById(R.id.addStockButton);
        addStockButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UpdateStock.this, AddStock.class);
                startActivity(intent);
            }
        });

        // Handle click on "remove Stock" Button
        Button removeStockButton = findViewById(R.id.removeStockButton);
        removeStockButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedPosition = stockAdapter.getSelectedPosition();
                if (selectedPosition != RecyclerView.NO_POSITION) {
                    Stock selectedStock = stockList.get(selectedPosition);
                    String selectedStockTitle = selectedStock.getTitle();

                    // Remove the selected item from Firebase Realtime Database
                    DatabaseReference stockRef = FirebaseDatabase.getInstance().getReference("Stock").child(selectedStockTitle);
                    stockRef.removeValue()
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Toast.makeText(UpdateStock.this, "Stock removed successfully", Toast.LENGTH_SHORT).show();
                                    stockAdapter.setSelectedPosition(RecyclerView.NO_POSITION); // Reset selected position
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(UpdateStock.this, "Failed to remove stock", Toast.LENGTH_SHORT).show();
                                }
                            });
                } else {
                    Toast.makeText(UpdateStock.this, "Please select a stock item to remove", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
