package com.example.softwarepatterns;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class purchaseHandler {
    public static void completePurchase(String username) {
        // Get a reference to the user's database
        DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("Users").child(username);

        // Get a reference to the "baskets" node under the user's database
        DatabaseReference basketsRef = userRef.child("baskets");

        // Get a reference to the "purchases" node under the user's database
        DatabaseReference purchasesRef = userRef.child("purchases");

        // Read the basket data
        basketsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot basketSnapshot : dataSnapshot.getChildren()) {
                    // Get basket item details
                    String title = basketSnapshot.child("title").getValue(String.class);
                    String manufacturer = basketSnapshot.child("manufacturer").getValue(String.class);
                    int price = basketSnapshot.child("price").getValue(Integer.class);
                    int quantity = basketSnapshot.child("quantity").getValue(Integer.class);

                    // Create a purchase object and push it to purchases
                    purchases purchases = new purchases(title, manufacturer, price, quantity);
                    purchasesRef.push().setValue(purchases);
                }

                // Remove all items from the basket
                basketsRef.removeValue();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle errors
            }
        });
    }
}
