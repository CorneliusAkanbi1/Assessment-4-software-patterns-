package com.example.softwarepatterns;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class CardDetails extends AppCompatActivity {

    private EditText cardNumberEditText;
    private EditText expireDateEditText;
    private EditText cvvEditText;
    private EditText cardNameEditText;
    private Button purchaseButton;

    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_details);

        username = getIntent().getStringExtra("username");

        if (username == null || username.isEmpty()) {
            // Handle the case where username is not provided
            Toast.makeText(this, "Username not found", Toast.LENGTH_SHORT).show();
            finish(); // Finish the activity if username is not provided
            return;
        }

        cardNumberEditText = findViewById(R.id.CardNumber);
        expireDateEditText = findViewById(R.id.expireDate);
        cvvEditText = findViewById(R.id.cvv);
        cardNameEditText = findViewById(R.id.cardName);
        purchaseButton = findViewById(R.id.purchase_button);

        purchaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCardDetails();
            }
        });
    }

    private void saveCardDetails() {
        String cardNumber = cardNumberEditText.getText().toString().trim();
        String expireDate = expireDateEditText.getText().toString().trim();
        String cvv = cvvEditText.getText().toString().trim();
        String cardName = cardNameEditText.getText().toString().trim();

        // Validate card details
        if (cardNumber.length() != 16 || expireDate.length() != 4 || cvv.length() != 3 || cardName.isEmpty()) {
            Toast.makeText(this, "Card details are incorrect", Toast.LENGTH_SHORT).show();
            return;
        }

        // Save card details under the specific username node in Firebase
        DatabaseReference cardRef = FirebaseDatabase.getInstance().getReference("Users").child(username).child("cardDetails");
        Card card = new Card(cardNumber, expireDate, cvv, cardName);
        cardRef.setValue(card);

        Toast.makeText(this, "Card details saved successfully", Toast.LENGTH_SHORT).show();
        finish(); // Finish the activity after saving card details
    }

}
