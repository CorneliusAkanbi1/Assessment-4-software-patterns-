package com.example.softwarepatterns;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class checkout extends AppCompatActivity {

    private RecyclerView recyclerViewShop;
    private CheckoutAdapter checkoutAdapter;
    private List<BasketItem> basketItemList;
    private TextView checkoutRedirectText;

    private DatabaseReference databaseReference;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        // Retrieve username from SharedPreferences or intent, however you stored it
        username = getIntent().getStringExtra("username");

        if (username == null || username.isEmpty()) {
            // Handle the case where username is not provided
            Toast.makeText(this, "Username not found", Toast.LENGTH_SHORT).show();
            finish(); // Finish the activity if username is not provided
            return;
        }

        recyclerViewShop = findViewById(R.id.recyclerViewShop);
        recyclerViewShop.setHasFixedSize(true);
        recyclerViewShop.setLayoutManager(new LinearLayoutManager(this));

        basketItemList = new ArrayList<>();
        checkoutAdapter = new CheckoutAdapter(basketItemList, this);
        recyclerViewShop.setAdapter(checkoutAdapter);

        // Retrieve the user's baskets from Firebase and populate the RecyclerView
        databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(username).child("baskets");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                basketItemList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    BasketItem basketItem = snapshot.getValue(BasketItem.class);
                    basketItemList.add(basketItem);
                }
                checkoutAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle database error
            }
        });

        checkoutRedirectText = findViewById(R.id.checkoutRedirectText);
        checkoutRedirectText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(checkout.this, MainActivity.class);
                startActivity(intent);
            }
        });

        Button checkoutButton = findViewById(R.id.checkout_button);
        checkoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(checkout.this, CardDetails.class);
                intent.putExtra("username", username);
                startActivity(intent);
            }
        });
    }

}
