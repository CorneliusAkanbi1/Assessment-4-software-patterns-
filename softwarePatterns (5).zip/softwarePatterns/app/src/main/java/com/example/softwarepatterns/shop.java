// shop.java

package com.example.softwarepatterns;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class shop extends AppCompatActivity {

    private RecyclerView recyclerViewShop;
    private StockAdapter stockAdapter;
    private List<Stock> stockList;
    private TextView shopRedirectText;
    private SearchView searchView;
    private Button addToBasketButton;
    private NumberPicker numberPicker;

    private DatabaseReference databaseReference;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop);

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("username")) {
            username = intent.getStringExtra("username");
        } else {
            Toast.makeText(this, "Username not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        recyclerViewShop = findViewById(R.id.recyclerViewShop);
        recyclerViewShop.setHasFixedSize(true);
        recyclerViewShop.setLayoutManager(new LinearLayoutManager(this));

        stockList = new ArrayList<>();
        stockAdapter = new StockAdapter(stockList);
        recyclerViewShop.setAdapter(stockAdapter);

        databaseReference = FirebaseDatabase.getInstance().getReference("Stock");

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                stockList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Stock stock = snapshot.getValue(Stock.class);
                    stockList.add(stock);
                }
                stockAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle database error
            }
        });

        shopRedirectText = findViewById(R.id.shopRedirectText);
        shopRedirectText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(shop.this, MainActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);
            }
        });

        searchView = findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                stockAdapter.filterList(newText);
                return true;
            }
        });

        addToBasketButton = findViewById(R.id.AddToBasket_button);
        addToBasketButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addToBasket();
            }
        });

        numberPicker = findViewById(R.id.numberPicker);
        numberPicker.setMinValue(1);
        numberPicker.setMaxValue(100);

        stockAdapter.setOnItemClickListener(new StockAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                // Do something when an item is clicked
            }
        });
    }

    private void addToBasket() {
        int selectedItemPosition = stockAdapter.getSelectedPosition();
        if (selectedItemPosition != RecyclerView.NO_POSITION) {
            Stock selectedStock = stockList.get(selectedItemPosition);
            int quantity = numberPicker.getValue();

            DatabaseReference basketRef = FirebaseDatabase.getInstance().getReference("Users")
                    .child(username).child("baskets");
            String basketItemId = basketRef.push().getKey();

            BasketItem basketItem = new BasketItem(selectedStock.getTitle(), selectedStock.getManufacturer(),
                    selectedStock.getPrice(), quantity);

            basketRef.child(basketItemId).setValue(basketItem);
            Toast.makeText(this, "Item added to basket", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Please select an item first", Toast.LENGTH_SHORT).show();
        }
    }
}
